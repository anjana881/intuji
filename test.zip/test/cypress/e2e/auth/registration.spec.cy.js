const users = require("../../fixtures/signupUser.json");
describe("Registration in the application", () => {
  beforeEach(() => {
    cy.visit("https://automationexercise.com/");
    cy.get("a[href='/login']").click();
  });

  it("sign up", () => {
    cy.get("input[placeholder='Name']").type(users.fname);
    cy.get("input[data-qa='signup-email']").type(users.email);
    cy.get('[data-qa="signup-button"]').click();
    // address information
    cy.get("#name").type(users.fname);

    cy.get("#password").type(users.password);
    cy.get("#first_name").type(users.fname);
    cy.get("#last_name").type(users.lname);
    cy.get("#address1").type(users.address1);
    cy.get("#state").type(users.state);
    cy.get("#city").type(users.city);
    cy.get("#zipcode").type(users.zipcode);
    cy.get("#mobile_number").type(users.mobile_number);

    cy.get("button[data-qa='create-account']").click();
    cy.get("h2[class='title text-center'] b").should(
      "have.text",
      "Account Created!"
    );
  });
});
